package sample;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;

import java.util.concurrent.LinkedBlockingDeque;

public class Main extends Application {
    Stage primaryStageObj;
    @Override
    public void start(Stage primaryStage) throws Exception{
        Parent root = FXMLLoader.load(getClass().getResource("sample.fxml"));
        primaryStage.setTitle("Hello World");
        primaryStage.setScene(new Scene(root, 1000, 500));
        primaryStage.toFront();
        primaryStage.getIcons().add(new Image(this.getClass().getResourceAsStream("icon.png")));


        primaryStage.show();
        primaryStageObj = primaryStage;
    }

    public static Thread china;
    public static void main(String[] args) {
        threadboy threadboyobj = new threadboy();
        threadboyobj.start();
         china = new Thread(){
            public static LinkedBlockingDeque<Boolean> killSwitch = new LinkedBlockingDeque<Boolean>();

            @Override
            public void run(){
                while(killSwitch.isEmpty()){
                    try {
                        sleep(500);
                    }catch (Exception e){
                        e.printStackTrace();
                    }
                }
                boolean x = killSwitch.poll();
                if(x) System.exit(500);
                run();
            }
        };
        china.start();
        launch(args);



    }
}
