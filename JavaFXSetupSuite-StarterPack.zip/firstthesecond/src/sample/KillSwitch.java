package sample;

import javafx.stage.Stage;

import java.util.concurrent.LinkedBlockingDeque;

public class KillSwitch extends Thread{
    public static LinkedBlockingDeque<Boolean> killSwitch = new LinkedBlockingDeque<Boolean>();

    @Override
    public void run(){
        while(killSwitch.isEmpty()){
            try {
                sleep(500);
            }catch (Exception e){
                e.printStackTrace();
            }
        }
        boolean x = killSwitch.poll();
        if(x) System.exit(500);
        run();
    }
    public static void deleteStage(Stage stage){
        try{
            stage.close();
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }

}
