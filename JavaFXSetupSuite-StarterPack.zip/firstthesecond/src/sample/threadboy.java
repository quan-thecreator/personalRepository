package sample;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.concurrent.LinkedBlockingQueue;

public class threadboy extends Thread{
    File logs = new File("chinalog.txt");

   public static LinkedBlockingQueue<String> dropper
            = new LinkedBlockingQueue<String>();
    public void run() {
        //System.out.println("Hello!");
    while(dropper.isEmpty()){
        try {
            sleep(500);
        } catch (Exception e){e.printStackTrace();}
    }
       try {
           if (logs.createNewFile()) {
               System.out.println("File created: " + logs.getName());
           }
       }
       catch (Exception e){
           e.printStackTrace();
       }
        try {
            FileWriter myWriter = new FileWriter("chinalog.txt", true);
            myWriter.append(
                dropper.poll() + "\n"
         );
            myWriter.close();
            //System.out.println("Successfully wrote to the file.");
        } catch (IOException e) {
           // System.out.println("An error occurred.");
            e.printStackTrace();
        }
        run();

       //still method stuff
    }
    //the class teritory
}
