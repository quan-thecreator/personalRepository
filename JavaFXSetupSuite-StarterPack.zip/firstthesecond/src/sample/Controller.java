package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;

import java.net.URL;
import java.util.ResourceBundle;

public class Controller {
    @FXML
    private TextField idea;
    public void initialize(URL url, ResourceBundle rb){

    }
    @FXML
public  void log(MouseEvent mouseEvent){
    System.out.println("HA");
    String ideaString = null;
    ideaString = idea.getText();
    threadboy.dropper.add(ideaString);
}




}
